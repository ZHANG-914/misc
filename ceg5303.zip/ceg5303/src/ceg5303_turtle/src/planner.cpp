#include "ceg5303_turtle/planner.hpp"

namespace ceg5303::turtle
{

// ======================== Nav2 Planner Plugin ===============================
void Planner::configure(
    const rclcpp_lifecycle::LifecycleNode::WeakPtr &parent,
    std::string name, const std::shared_ptr<tf2_ros::Buffer> tf,
    const std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros)
{
    // Initialize states / variables
    node_ = parent.lock(); 
    tf_ = tf;
    plugin_name_ = name;
    costmap_ = costmap_ros->getCostmap();
    global_frame_id_ = costmap_ros->getGlobalFrameID();

    // Initialize parameters
    initParam(node_, plugin_name_ + ".max_access_cost", max_access_cost_, 255);
    initParam(node_, plugin_name_ + ".interpolation_distance", interpolation_distance_, 0.05);
    initParam(node_, plugin_name_ + ".sg_half_window", sg_half_window_, 5);
    initParam(node_, plugin_name_ + ".sg_order", sg_order_, 3);
}

// Create a path plan from start to goal
nav_msgs::msg::Path Planner::createPlan(
    const geometry_msgs::msg::PoseStamped &start,
    const geometry_msgs::msg::PoseStamped &goal)
{
    PlannerNodes nodes(costmap_->getSizeInCellsX(), costmap_->getSizeInCellsY());
    OpenList open_list;

    // Convert world coordinates to map coordinates
    int start_mx, start_my, goal_mx, goal_my;
    costmap_->worldToMapEnforceBounds(
        start.pose.position.x, start.pose.position.y,
        start_mx, start_my);
    costmap_->worldToMapEnforceBounds(
        goal.pose.position.x, goal.pose.position.y,
        goal_mx, goal_my);
    
    // Set start point parameters
    nodes.getNode(start_mx, start_my)->g = 0;
    nodes.getNode(start_mx, start_my)->h = std::hypot(goal_mx - start_mx, goal_my - start_my);
    open_list.queue(nodes.getNode(start_mx, start_my));

    // A* algorithm implementation
    std::vector<std::array<int, 2>> coords;
    while (!open_list.empty())
    {
        PlannerNode *curr_node = open_list.pop();
        if (curr_node->expanded)
        {
            continue;
        }
        else if (curr_node->mx == goal_mx && curr_node->my == goal_my)
        {
            // Goal reached, backtrack to extract the path
            while (curr_node != nullptr)
            {
                std::array<int, 2> coord = {curr_node->mx, curr_node->my};
                coords.push_back(coord);
                curr_node = curr_node->parent;
            }
            std::reverse(coords.begin(), coords.end());
            break;
        }
        
        // Mark current node as expanded
        curr_node->expanded = true;
        
        // Explore neighboring nodes
        for (int i = -1; i < 2; i++)
        {
            for (int j = -1; j < 2; j++)
            {
                if (i == 0 && j == 0)
                {
                    continue;
                }
                PlannerNode *neighbor_node = nodes.getNode(curr_node->mx + i, curr_node->my + j);
                if (neighbor_node == nullptr)
                {
                    continue;
                }
                
                // Compute cost
                double cost = costmap_->getCost(neighbor_node->mx, neighbor_node->my) + 1;
                cost = (cost < max_access_cost_) ? cost : INFINITY;
                double temp_g = curr_node->g + std::hypot(i, j) + cost;
                
                // If a better path is found, update the node
                if (temp_g < neighbor_node->g)
                {
                    neighbor_node->g = temp_g;
                    neighbor_node->parent = curr_node;
                    neighbor_node->h = hypot(neighbor_node->mx - goal_mx, neighbor_node->my - goal_my);
                    neighbor_node->f = neighbor_node->h + temp_g;
                    open_list.queue(neighbor_node);
                }
            }
        }
    }

    // Create path message
    nav_msgs::msg::Path generated_path = writeToPath(coords, goal);
    
    // Smooth the path
    smoothPath(generated_path);

    return generated_path;
}

// =================== Path Processing  ===================================
// Smooth the path using a Savitzky-Golay filter
void Planner::smoothPath(nav_msgs::msg::Path &path)
{
    // Create Savitzky-Golay filter matrix
    int r = 2 * sg_half_window_ + 1;
    int c = sg_order_ + 1;
    Eigen::MatrixXd J(r, c);
    Eigen::MatrixXd a(r, c);
    
    for (int i = 0; i < r; i++)
    {
        for (int j = 0; j < c; j++)
        {
            J(i, j) = std::pow((-1 * sg_half_window_ + i), j);
        }
    }
    
    // Compute filter coefficients
    a = (J.transpose() * J).inverse() * J.transpose();
    Eigen::RowVectorXd alpha = a.row(0);
    
    int path_size = static_cast<int>(path.poses.size());
    
    // Apply the filter to smooth the path
    for (size_t i = 0; i < path.poses.size(); i++)
    {   
        double resx = 0;
        double resy = 0;
        
        for (int j = 0; j < r; j++)
        {
            int k = i + 1 + j - sg_half_window_;
            if (k < 1)
            {
                k = 1;
            }
            else if (k > path_size - 1)
            {
                k = path_size - 1;
            }
            
            resx += path.poses[k].pose.position.x * alpha(j - sg_half_window_ + sg_half_window_);
            resy += path.poses[k].pose.position.y * alpha(j - sg_half_window_ + sg_half_window_);
        }
        
        // Update point position
        path.poses[i].pose.position.x = resx;
        path.poses[i].pose.position.y = resy;
    }
}

// ======================== Path Data Conversion ===================================
nav_msgs::msg::Path Planner::writeToPath(
    std::vector<std::array<int, 2>> coords,
    geometry_msgs::msg::PoseStamped goal)
{
    nav_msgs::msg::Path path;
    path.poses.clear();
    path.header.frame_id = global_frame_id_;
    path.header.stamp = node_->now();

    // Add each coordinate point to the path
    for (const auto &coord : coords)
    {
        // Convert map coordinates to world coordinates
        double wx, wy;
        costmap_->mapToWorld(coord[0], coord[1], wx, wy);
        
        // Create and add pose 
        geometry_msgs::msg::PoseStamped pose;
        pose.pose.position.x = wx;
        pose.pose.position.y = wy;
        pose.pose.orientation.w = 1; // normalized quaternion
        path.poses.push_back(pose);
    }

    // Add goal pose 
    goal.header.frame_id = "";         
    goal.header.stamp = rclcpp::Time();
    path.poses.push_back(goal);

    return path;
}

// ======================== Lifecycle Management ===================================
void Planner::cleanup()
{
    RCLCPP_INFO_STREAM(node_->get_logger(), "Cleaning up plugin " << plugin_name_ << " of type ceg5303::turtle::Planner");
}

void Planner::activate()
{
    RCLCPP_INFO_STREAM(node_->get_logger(), "Activating plugin " << plugin_name_ << " of type ceg5303::turtle::Planner");
}

void Planner::deactivate()
{
    RCLCPP_INFO_STREAM(node_->get_logger(), "Deactivating plugin " << plugin_name_ << " of type ceg5303::turtle::Planner");
}

// ======================== Helper Class Implementations =====================================
// ======================== Planner Node =================================
PlannerNode::PlannerNode(int mx, int my) : mx(mx), my(my) {}

// ======================== Open List Implementations  ===================
bool OpenListComparator::operator()(PlannerNode *l, PlannerNode *r) const { return l->f > r->f; }

void OpenList::queue(PlannerNode *node) { pq.push(node); }

PlannerNode *OpenList::pop()
{
    if (pq.empty())
        return nullptr;
    PlannerNode *cheapest_node = pq.top();
    pq.pop();
    return cheapest_node;
}
bool OpenList::empty() const { return pq.empty(); }

// ======================== Nodes ===============================
PlannerNodes::PlannerNodes(int num_cells_x, int num_cells_y)
{
    size_mx = num_cells_x;
    size_my = num_cells_y;

    nodes.reserve(num_cells_x * num_cells_y);
    for (int mx = 0; mx < size_mx; ++mx)
        for (int my = 0; my < size_my; ++my)
            nodes[mx * size_my + my] = PlannerNode(mx, my);
}

PlannerNode *PlannerNodes::getNode(int mx, int my)
{
    if (mx < 0 || my < 0 || mx >= size_mx || my >= size_my)
        return nullptr;
    return &nodes[mx * size_my + my];
}

} // namespace ceg5303::turtle

// Register the plugin
PLUGINLIB_EXPORT_CLASS(ceg5303::turtle::Planner, nav2_core::GlobalPlanner)
