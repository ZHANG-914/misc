#include "ceg5303_turtle/controller.hpp"

namespace ceg5303::turtle
{
    void Controller::cleanup() { RCLCPP_INFO_STREAM(node_->get_logger(), "Cleaning up plugin " << plugin_name_ << " of type ceg5303::turtle::Controller"); }

    void Controller::activate() { RCLCPP_INFO_STREAM(node_->get_logger(), "Activating plugin " << plugin_name_ << " of type ceg5303::turtle::Controller"); }

    void Controller::deactivate() { RCLCPP_INFO_STREAM(node_->get_logger(), "Deactivating plugin " << plugin_name_ << " of type ceg5303::turtle::Controller"); }

    void Controller::setSpeedLimit(const double &speed_limit, const bool &percentage)
    {
        (void)speed_limit;
        (void)percentage;
    }

    void Controller::setPlan(const nav_msgs::msg::Path &path) { global_plan_ = path; }

    // ====================================== LAB 1, PROJ 1 ====================================================

    void Controller::configure(
        const rclcpp_lifecycle::LifecycleNode::WeakPtr &parent,
        std::string name, const std::shared_ptr<tf2_ros::Buffer> tf,
        const std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros)
    {
        (void)costmap_ros;

        // initialize states / variables
        node_ = parent.lock(); // this class is not a node_. It is instantiated as part of a node_ `parent`.
        tf_ = tf;
        plugin_name_ = name;

        // initialize parameters
        initParam(node_, plugin_name_ + ".desired_linear_vel", desired_linear_vel_, 0.2);
        initParam(node_, plugin_name_ + ".desired_lookahead_dist", desired_lookahead_dist_, 0.3);
        initParam(node_, plugin_name_ + ".max_angular_vel", max_angular_vel_, 1.0);
        initParam(node_, plugin_name_ + ".max_linear_vel", max_linear_vel_, 0.22);
        initParam(node_, plugin_name_ + ".xy_goal_thres", xy_goal_thres_, 0.05);
        initParam(node_, plugin_name_ + ".yaw_goal_thres", yaw_goal_thres_, 0.25);
        initParam(node_, plugin_name_ + ".curvature_threshold", curvature_threshold, 1.5);
        initParam(node_, plugin_name_ + ".proximity_threshold", proximity_threshold, 0.7);
        initParam(node_, plugin_name_ + ".lookahead_gain", lookahead_gain, 3.0);

        adjusted_lookahead = desired_lookahead_dist_;

        //initialize topics
        sub_scan_ = node_->create_subscription<sensor_msgs::msg::LaserScan>(
            "/scan", rclcpp::SensorDataQoS(),
            std::bind(&Controller::scannerCallback, this, std::placeholders::_1));
    }

    void Controller::scannerCallback(const sensor_msgs::msg::LaserScan::SharedPtr msg)
    {
        scan_ranges_ = msg->ranges;
    }

    //  Get target pose(includes the target position and orientation from "click")
    geometry_msgs::msg::TwistStamped Controller::computeVelocityCommands(
        const geometry_msgs::msg::PoseStamped &pose,
        const geometry_msgs::msg::Twist &velocity,
        nav2_core::GoalChecker *goal_checker)
    {
        (void)velocity;     
        (void)goal_checker; 
    
        // Check if the path exists
        if (global_plan_.poses.empty())
        {
            RCLCPP_WARN_STREAM(node_->get_logger(), "Global plan is empty!");
            return writeCmdVel(0, 0);
        }
    
        // Get target pose(includes the target position and orientation from "click")
        geometry_msgs::msg::PoseStamped goal_pose = global_plan_.poses.back();
        
        double goal_x = goal_pose.pose.position.x;
        double goal_y = goal_pose.pose.position.y;
        double goal_yaw = ceg5303::getYawFromQuaternion(goal_pose.pose.orientation);
    
        // Get current robot state
        double robot_x = pose.pose.position.x;                            // Robot X coordinate
        double robot_y = pose.pose.position.y;                            // Robot Y coordinate
        double phi = ceg5303::getYawFromQuaternion(pose.pose.orientation); // Robot orientation
    
        // Check if the robot is close to the goal (distance and yaw)
        double dist_to_goal = std::hypot(goal_x - robot_x, goal_y - robot_y);
        double diff_yaw = ceg5303::limitAngle(goal_yaw - phi);
    
        // If the goal is fully reached (position and orientation), stop
        if (dist_to_goal < xy_goal_thres_ && std::abs(diff_yaw) < yaw_goal_thres_)
        {
            RCLCPP_INFO_STREAM(node_->get_logger(), "Goal reached!");
            return writeCmdVel(0, 0);
        }
    
        // Define transition zone size - start adjusting orientation within this distance
        double pose_transition_zone = 0.4; 
        
        // Define orientation adjustment weight
        double orientation_weight = 0.0;
    
        // Start adjusting orientation weight when close to goal
        if (dist_to_goal < pose_transition_zone)
        {
            //  Smooth transition function: weight increases as distance decreases
            double progress = 1.0 - (dist_to_goal / pose_transition_zone);
            orientation_weight = progress * progress;
        }
    
        // Heading control term - adjusted by distance-based weight
        double heading_control = diff_yaw * orientation_weight;
    
        // If close to the final goal, fine-tune alignment
        if (dist_to_goal < xy_goal_thres_ * 2.0)
        {
            heading_control = diff_yaw;
            
            // If very close to goal, reduce linear velocity and focus on alignment
            if (dist_to_goal < xy_goal_thres_)
            {
                double angular_vel = std::clamp(heading_control * max_angular_vel_, -max_angular_vel_, max_angular_vel_);
                return writeCmdVel(0, angular_vel);
            }
        }
        

        // Find the closest path point
        size_t closest_index = 0;
        double shortest_dist = std::numeric_limits<double>::max();
        for (size_t i = 0; i < global_plan_.poses.size(); i++)
        {
            double point_pose_x = global_plan_.poses[i].pose.position.x; 
            double point_pose_y = global_plan_.poses[i].pose.position.y;
            double dist = std::hypot((point_pose_x - robot_x), (point_pose_y - robot_y));
    
            if (dist < shortest_dist) 
            {
                shortest_dist = dist;
                closest_index = i;
            }
        }

        // Initialize the lookahead point as the goal point
        geometry_msgs::msg::PoseStamped lookahead_pose = goal_pose;

        // Determine the lookahead point
        for (size_t j = closest_index + 1; j < global_plan_.poses.size(); j++)
        {
            double point_pose_x = global_plan_.poses[j].pose.position.x; 
            double point_pose_y = global_plan_.poses[j].pose.position.y;
            double dist_from_robot = std::hypot((point_pose_x - robot_x), (point_pose_y - robot_y));

            if (dist_from_robot >= adjusted_lookahead) 
            {
                lookahead_pose = global_plan_.poses[j];
                break;
            }
        }

        // Compute the lookahead point coordinates in the robot frame
        double delta_x = lookahead_pose.pose.position.x - robot_x;
        double delta_y = lookahead_pose.pose.position.y - robot_y;

        // Transform coordinates to the robot frame
        double x_r = delta_x * std::cos(phi) + delta_y * std::sin(phi); 
        double y_r = delta_y * std::cos(phi) - delta_x * std::sin(phi);

        // Compute curvature
        double d_squared = std::pow(x_r, 2) + std::pow(y_r, 2);
        double curvature = 2 * y_r / d_squared;

        // Compute angular velocity based on curvature
        double angular_vel = desired_linear_vel_ * curvature;

        // Curvature-based adjustment - Reduce linear velocity in high-curvature regions
        double regulated_linear_vel = desired_linear_vel_;

        if (curvature_threshold < std::abs(curvature))
        {
            regulated_linear_vel = desired_linear_vel_ * (curvature_threshold / std::abs(curvature));
        }

        // Find the minimum obstacle distance
        double min_obstacle_dist = std::numeric_limits<double>::max();

        for (const auto &range: scan_ranges_)
        {
            if (range < min_obstacle_dist && std::isfinite(range))
            {
                min_obstacle_dist = range;
            }
        }

        // Obstacle-based adjustment - Reduce linear velocity when approaching obstacles
        if (min_obstacle_dist < proximity_threshold)
        {
            regulated_linear_vel = regulated_linear_vel * (min_obstacle_dist / proximity_threshold);
        }

        // Dynamically adjust the lookahead distance - Higher speed results in a greater lookahead distance
        std::cout << "regulated linear " << regulated_linear_vel << std::endl;
        adjusted_lookahead = regulated_linear_vel * lookahead_gain;
        
        // Clamp velocity within the safe range
        regulated_linear_vel = std::clamp(regulated_linear_vel, -max_linear_vel_, max_linear_vel_);
        angular_vel = std::clamp(angular_vel, -max_angular_vel_, max_angular_vel_);

        return writeCmdVel(regulated_linear_vel, angular_vel);
    }

    geometry_msgs::msg::TwistStamped Controller::writeCmdVel(double linear_vel, double angular_vel)
    {
        geometry_msgs::msg::TwistStamped cmd_vel;
        cmd_vel.twist.linear.x = linear_vel;
        cmd_vel.twist.angular.z = angular_vel;
        return cmd_vel;
    }
}

PLUGINLIB_EXPORT_CLASS(ceg5303::turtle::Controller, nav2_core::Controller)